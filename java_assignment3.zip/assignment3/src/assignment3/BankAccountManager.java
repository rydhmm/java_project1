package assignment3;

import java.util.InputMismatchException;
import java.util.Scanner;

public class BankAccountManager {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            // Create Account
            System.out.print("Enter Account ID: ");
            int accountId = sc.nextInt();
            sc.nextLine(); // Consume newline

            System.out.print("Enter Account Holder Name: ");
            String holderName = sc.nextLine();

            System.out.print("Enter Initial Balance: ");
            double initialBalance = sc.nextDouble();

            BankAccount account = new BankAccount(accountId, holderName, initialBalance);

            // Menu Loop
            while (true) {
                System.out.println("\n--- Bank Menu ---");
                System.out.println("1. Deposit Money");
                System.out.println("2. Withdraw Money");
                System.out.println("3. View Balance");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");

                int option = sc.nextInt();

                try {
                    switch (option) {
                        case 1:
                            System.out.print("Enter deposit amount: ");
                            double depositAmount = sc.nextDouble();
                            account.deposit(depositAmount);
                            break;

                        case 2:
                            System.out.print("Enter withdrawal amount: ");
                            double withdrawAmount = sc.nextDouble();
                            account.withdraw(withdrawAmount);
                            break;

                        case 3:
                            account.viewBalance();
                            break;

                        case 4:
                            System.out.println("Exiting...");
                            return;

                        default:
                            System.out.println("Invalid option, try again.");
                    }
                } catch (InvalidAmountException | InsufficientFundsException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input type. Please enter numeric values where expected.");
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
