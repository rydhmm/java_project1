package assignment3;

public class BankAccount {
    private int accountId;
    private String accountHolderName;
    private double balance;

    public BankAccount(int accountId, String accountHolderName, double initialBalance) {
        this.accountId = accountId;
        this.accountHolderName = accountHolderName;
        this.balance = initialBalance;
    }

    public void deposit(double amount) throws InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Deposit amount must be positive.");
        }
        this.balance += amount;
        System.out.println("Deposited: " + amount + ", Current balance: " + this.balance);
    }

    public void withdraw(double amount) throws InsufficientFundsException, InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Withdrawal amount must be positive.");
        }
        if (amount > this.balance) {
            throw new InsufficientFundsException("Insufficient funds. Current balance: " + this.balance);
        }
        this.balance -= amount;
        System.out.println("Withdrawn: " + amount + ", Current balance: " + this.balance);
    }

    public void viewBalance() {
        System.out.println("Current balance: " + this.balance);
    }

    public void accountDetails() {
        System.out.println("Account ID: " + accountId);
        System.out.println("Account Holder: " + accountHolderName);
        System.out.println("Balance: " + balance);
    }
}
