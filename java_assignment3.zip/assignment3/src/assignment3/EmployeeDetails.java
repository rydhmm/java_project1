package assignment3;

import java.util.Scanner;

class InvalidEmployeeNameException extends Exception {
    public InvalidEmployeeNameException(String message) {
        super(message);
    }
}

class InvalidEmployeeIDException extends Exception {
    public InvalidEmployeeIDException(String message) {
        super(message);
    }
}

class InvalidDepartmentIDException extends Exception {
    public InvalidDepartmentIDException(String message) {
        super(message);
    }
}

public class EmployeeDetails {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            // Input Employee ID
            System.out.print("Enter Employee ID: ");
            int empId = sc.nextInt();
            sc.nextLine(); // **clear newline**

            if (empId < 2001 || empId > 5001) {
                throw new InvalidEmployeeIDException("Employee ID must be between 2001 and 5001.");
            }

            // Input Employee Name
            System.out.print("Enter Employee Name: ");
            String name = sc.nextLine();

            if (!Character.isUpperCase(name.charAt(0))) {
                throw new InvalidEmployeeNameException("Employee name must start with a capital letter.");
            }

            // Input Department ID
            System.out.print("Enter Department ID: ");
            int deptId = sc.nextInt();

            if (deptId < 1 || deptId > 5) {
                throw new InvalidDepartmentIDException("Department ID must be between 1 and 5.");
            }

            // Display details if everything valid
            System.out.println("\nEmployee Details:");
            System.out.println("Employee ID: " + empId);
            System.out.println("Employee Name: " + name);
            System.out.println("Department ID: " + deptId);

        } catch (InvalidEmployeeIDException | InvalidEmployeeNameException | InvalidDepartmentIDException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
