package assignment3;

import java.util.Scanner;

class MyCalculator {

    // Power method to calculate n^p
    public int power(int n, int p) throws Exception {
        // Handle cases where n or p is negative
        if (n < 0 || p < 0) {
            throw new Exception("n or p should not be negative.");
        } 
        // Handle case where both n and p are zero
        else if (n == 0 && p == 0) {
            throw new Exception("n and p should not be zero.");
        } 
        // Calculate the power
        else {
            return (int) Math.pow(n, p);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        MyCalculator myCalc = new MyCalculator();

        // Keep reading input while there's more data
        while (sc.hasNext()) {
            int n = sc.nextInt();
            int p = sc.nextInt();

            try {
                // Calculate the result and print it
                int result = myCalc.power(n, p);
                System.out.println(result);
            } catch (Exception e) {
                // Handle exceptions (e.g. negative n or p, both being 0)
                System.out.println(e.getMessage());
            }
        }

        sc.close(); // Close scanner when done
    }
}
