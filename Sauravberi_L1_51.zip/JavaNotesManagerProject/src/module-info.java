/**
 * 
 */
/**
 * 
 */
module JavaNotesManagerProject {
}